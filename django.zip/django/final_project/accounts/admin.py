from django.contrib import admin
from .models import logindetails

# Register your models here.
admin.site.register(logindetails)